#include<stdio.h>

int main()
{
	float a;
	scanf("%f",&a);
	printf("\nOUTPUT:\n%.2f",a*a);
}
