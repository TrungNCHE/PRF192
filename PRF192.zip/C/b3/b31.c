#include<stdio.h>

int main()
{
	float a;
	scanf("%f",&a);
	printf("\nOUTPUT:\n%.3f",a*4);
}
