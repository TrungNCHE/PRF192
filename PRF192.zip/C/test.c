#include<stdio.h>
int main()
{
	float x=10.1456;
	printf("%.2f",x);
}
